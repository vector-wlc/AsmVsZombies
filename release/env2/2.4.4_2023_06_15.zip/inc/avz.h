/*
 * @Coding: utf-8
 * @Author: yuchenxi0_0 and vector-wlc
 * @Date: 2020-02-06 10:22:46
 * @Description: High-precision PvZ TAS Frameworks : Assembly vs. Zombies !
 */

#ifndef __AVZ_H__
#define __AVZ_H__

#include "libavz.h"

void AScript();

#define ACoScript()               \
    __ARealScript();              \
    void AScript()                \
    {                             \
        ACoLaunch(__ARealScript); \
    }                             \
    auto __ARealScript()->decltype(__ARealScript())

#endif