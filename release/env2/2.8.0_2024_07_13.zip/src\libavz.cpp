#include "libavz.h"

AIceFiller aIceFiller;
APlantFixer aPlantFixer;
ACobManager aCobManager;
AAliveFilter<AZombie> aAliveZombieFilter;
AAliveFilter<APlant> aAlivePlantFilter;
AAliveFilter<ASeed> aAliveSeedFilter;
AAliveFilter<APlaceItem> aAlivePlaceItemFilter;
APainter aPainter;
