/*
 * @coding: utf-8
 * @Author: vector-wlc
 * @Date: 2020-02-06 10:22:46
 * @Description: include some scripts
 */

#pragma once
#include "avz.h"

void Script();